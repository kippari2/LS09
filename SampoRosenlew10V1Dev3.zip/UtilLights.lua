--
-- originally known as "smerovky"
-- 
-- @author: DJ Lukes
-- @date: 9.12.09
-- @edited : kippari2 (KLS mods)
-- @edit date: 11.2.2024
-- @version 1.1
--

UtilLights = {};

function UtilLights.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function UtilLights:load(xmlFile)
    -- Brake lights
    self.brakeLightObject = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.utilLights.brake#index"));
    setVisibility(self.brakeLightObject, false);
    self.brakeLightActive = false;
    
    -- Turn lights
    self.leftTurnObject = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.utilLights.leftTurn#index"))
    setVisibility(self.leftTurnObject, false);
    self.leftTurnActive = false;
    self.flashLeft = false;
    
    self.rightTurnObject = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.utilLights.rightTurn#index"))
    setVisibility(self.rightTurnObject, false);
    self.rightTurnActive = false;
    self.flashRight = false;
    
    self.flash = false;
    self.flashWarn = false;
    self.timer = 10;
	
	turn1SoundFile = Utils.getFilename("Sounds/turn1.wav", self.baseDirectory);
	self.turn1 = createSample("turn1");
    loadSample(self.turn1, turn1SoundFile, false);
	turn2SoundFile = Utils.getFilename("Sounds/turn2.wav", self.baseDirectory);
	self.turn2 = createSample("turn2");
    loadSample(self.turn2, turn2SoundFile, false);
end;

function UtilLights:delete()
	delete(self.turn1);
    delete(self.turn2);
end;

function UtilLights:mouseEvent(posX, posY, isDown, isUp, button)
end;

function UtilLights:keyEvent(unicode, sym, modifier, isDown)
    -- Turn signals
    if InputBinding.isPressed(InputBinding.LEFTTURN) then
        if not self.flashLeft or self.flashWarn then
            self.flashLeft = false;
        end;
        self.flashLeft = not self.flashLeft;
        self.flashRight = false;
        self.flashWarn = false;
        self.timer = 10;
    end;
    if InputBinding.isPressed(InputBinding.RIGHTTURN) then
        if not self.flashRight or self.flashWarn then
            self.flashRight = false;
        end;
        self.flashRight = not self.flashRight;
        self.flashLeft = false;
        self.flashWarn = false;
        self.timer = 10;
    end;
    -- Warn lights
    if InputBinding.isPressed(InputBinding.WARNLIGHTS) then
        if self.flashWarn then
            self.flashLeft = false;
            self.flashRight = false;
        else
            self.rightTurnActive = false;
            self.leftTurnActive = false;
            self.flashLeft = true;
            self.flashRight = true;
        end;
        self.flashWarn = not self.flashWarn;
        self.timer = 10;
    end;
end;

function UtilLights:update(dt)
    -- Define input
    self.input = InputBinding.getAnalogInputAxis(InputBinding.AXIS_FORWARD);
    if InputBinding.isAxisZero(self.input) then
        self.input = InputBinding.getDigitalInputAxis(InputBinding.AXIS_FORWARD);
    end;
    
    -- Brake lights
    setVisibility(self.brakeLightObject, self.brakeLightActive);
    
    if (self.movingDirection*self.lastSpeed*(-self.input)) < -0.001 then
        self.brakeLightActive = true;
    else
        self.brakeLightActive = false;
    end;
    
	-- Turn lights
    if self.flashLeft or self.flashRight then
        self.timer = self.timer - dt;
        if self.flashRight or self.flashWarn then
            if self.timer < 0 then
                self.rightTurnActive = not self.rightTurnActive;
				playSample(self.turn1,1,0.7,0);
            end;
        else
            self.rightTurnActive = false;
        end;
    
        if self.flashLeft or self.flashWarn then
            if self.timer < 0 then
                self.leftTurnActive = not self.leftTurnActive;
				playSample(self.turn1,1,0.7,0);
            end;
        else
            self.leftTurnActive = false;
        end;
        if self.timer < 0 then
            self.timer = 500;
			playSample(self.turn2,1,0.7,0);
        end;
    else
        self.rightTurnActive = false;
        self.leftTurnActive = false;
    end;
    setVisibility(self.rightTurnObject, self.rightTurnActive);
    setVisibility(self.leftTurnObject, self.leftTurnActive);
end;

function UtilLights:draw()
end;

