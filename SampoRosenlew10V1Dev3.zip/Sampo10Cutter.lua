-- @author: kippari2 (KLS mods)
-- @date: 16.2.2024
-- Copyright (C) 

Sampo10Cutter = {};

function Sampo10Cutter.prerequisitesPresent(specializations)
    return true;
end;

function Sampo10Cutter:load(xmlFile)
	local bladeAnimRootNode = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.bladeMechanism#rootNode"));
    if bladeAnimRootNode ~= nil and bladeAnimRootNode ~= 0 then
        self.bladeAnimCharSet = getAnimCharacterSet(bladeAnimRootNode);
		local clip = getAnimClipIndex(self.bladeAnimCharSet, getXMLString(xmlFile, "vehicle.animatedParts.bladeMechanism#animationClip"));
		assignAnimTrackClip(self.bladeAnimCharSet, 0, clip);
		setAnimTrackLoopState(self.bladeAnimCharSet, 0, true);
		local bladeAnimSpeedScale = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.bladeMechanism#speedScale"), 1);
		setAnimTrackSpeedScale(self.bladeAnimCharSet, 0, bladeAnimSpeedScale);
    end;
	local armUDAnimRootNode =  Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.arm#rootNode1"));
    if armUDAnimRootNode ~= nil and armUDAnimRootNode ~= 0 then
        self.armUDAnimCharSet = getAnimCharacterSet(armUDAnimRootNode);
		local clip = getAnimClipIndex(self.armUDAnimCharSet, getXMLString(xmlFile, "vehicle.animatedParts.arm#animationClip1"));
		assignAnimTrackClip(self.armUDAnimCharSet, 0, clip);
		setAnimTrackLoopState(self.armUDAnimCharSet, 0, false);
		self.armUDAnimSpeedScale = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.arm#speedScale1"), 1);
		setAnimTrackTime(self.armUDAnimCharSet, 0, 150);
		self.armUDClipDuration = getAnimClipDuration(self.armUDAnimCharSet, clip);
    end;
	local reelFBAnimRootNode =  Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.arm#rootNode2"));
    if reelFBAnimRootNode ~= nil and reelFBAnimRootNode ~= 0 then
        self.reelFBAnimCharSet = getAnimCharacterSet(reelFBAnimRootNode);
		local clip = getAnimClipIndex(self.reelFBAnimCharSet, getXMLString(xmlFile, "vehicle.animatedParts.arm#animationClip2"));
		assignAnimTrackClip(self.reelFBAnimCharSet, 0, clip);
		setAnimTrackLoopState(self.reelFBAnimCharSet, 0, false);
		self.reelFBAnimSpeedScale = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.arm#speedScale2"), 1);
		self.reelFBClipDuration = getAnimClipDuration(self.reelFBAnimCharSet, clip);
    end;
	
	self.pwIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.pulleyWheel#index"));
end;

function Sampo10Cutter:keyEvent(unicode, sym, modifier, isDown)
	--[[if InputBinding.isPressed(InputBinding.CUTTERON) then
		self.reelStarted = not self.reelStarted;
	end; i experimented with separate thresher and cutter activation]]
end;

function Sampo10Cutter:update(dt)
	if self.reelStarted then
		rotate(self.pwIndex, dt * 0.04, 0, 0);
		enableAnimTrack(self.bladeAnimCharSet, 0);
	else
		disableAnimTrack(self.bladeAnimCharSet, 0);
	end;
	
	if InputBinding.isPressed(InputBinding.REELDOWN) then
		local speedScale = -self.armUDAnimSpeedScale;
		setAnimTrackSpeedScale(self.armUDAnimCharSet, 0, speedScale);
		enableAnimTrack(self.armUDAnimCharSet, 0);
	elseif InputBinding.isPressed(InputBinding.REELUP) then
		setAnimTrackSpeedScale(self.armUDAnimCharSet, 0, self.armUDAnimSpeedScale);
		enableAnimTrack(self.armUDAnimCharSet, 0);
	else
		disableAnimTrack(self.armUDAnimCharSet, 0);
	end;

	local armUDtime = getAnimTrackTime(self.armUDAnimCharSet, 0);
	if armUDtime < 0 then
		setAnimTrackTime(self.armUDAnimCharSet, 0, 0)
	end;
	if armUDtime > self.armUDClipDuration then
		setAnimTrackTime(self.armUDAnimCharSet, 0, self.armUDClipDuration)
	end;
	
	if InputBinding.isPressed(InputBinding.REELFORWARD) then
		local speedScale = -self.reelFBAnimSpeedScale;
		setAnimTrackSpeedScale(self.reelFBAnimCharSet, 0, speedScale);
		enableAnimTrack(self.reelFBAnimCharSet, 0);
	elseif InputBinding.isPressed(InputBinding.REELBACK) then
		setAnimTrackSpeedScale(self.reelFBAnimCharSet, 0, self.reelFBAnimSpeedScale);
		enableAnimTrack(self.reelFBAnimCharSet, 0);
	else
		disableAnimTrack(self.reelFBAnimCharSet, 0);
	end;
	
	local reelFBtime = getAnimTrackTime(self.reelFBAnimCharSet, 0);
	if reelFBtime < 0 then
		setAnimTrackTime(self.reelFBAnimCharSet, 0, 0)
	end;
	if reelFBtime > self.reelFBClipDuration then
		setAnimTrackTime(self.reelFBAnimCharSet, 0, self.reelFBClipDuration)
	end;
end;

function Sampo10Cutter:draw()
end;

function Sampo10Cutter:delete()
end;

function Sampo10Cutter:mouseEvent(posX, posY, isDown, isUp, button)
end;