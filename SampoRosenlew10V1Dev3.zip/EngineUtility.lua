--
-- Combined motorIgnition and rpmLimiter scripts with modifications
-- More scripts may be added later
-- motorIgnition allows you to start and stop the engine manually
-- rpmLimiter allows you to change the rpm similarly to a throttle
--
-- @original author(s): Templaer 
-- @original date(s): 01.05.09
-- @edited : kippari2 (KLS mods)
-- @date 15.2.2024
-- @version 1.0
--

EngineUtility = {};

function EngineUtility.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function EngineUtility:load(xmlFile)
    -- Booleans
    self.ignitionKey = false;
	self.allowedIgnition = false;                                                  
	
	-- Backup Stop Sound volume
    self.motorStopSoundVolume2 = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.motorStopSound#volume"), 1.0);
	
	local motorMaxRpmStr = getXMLString(xmlFile, "vehicle.motor#maxRpm");
    local motorMaxRpm1, motorMaxRpm2, motorMaxRpm3 = Utils.getVectorFromString(motorMaxRpmStr);
    motorMaxRpm1 = Utils.getNoNil(motorMaxRpm1, 800);
    motorMaxRpm2 = Utils.getNoNil(motorMaxRpm2, 1000);
    motorMaxRpm3 = Utils.getNoNil(motorMaxRpm3, 1800);
    local motorMaxRpm = {motorMaxRpm1, motorMaxRpm2, motorMaxRpm3};
    self.motorMaxRpmLimit = motorMaxRpm;
end;

function EngineUtility:delete()
end;

function EngineUtility:mouseEvent(posX, posY, isDown, isUp, button)
end;

function EngineUtility:keyEvent(unicode, sym, modifier, isDown)
end;

function EngineUtility:update(dt)
	-- Does not execute when AI is activated
    if not self.isAITractorActivated then
        -- Handles ignition key input
        if self:getIsActiveForInput() then
            if InputBinding.hasEvent(InputBinding.IGNITION) then
		        self.ignitionKey = not self.ignitionKey;
			    self.allowedIgnition = true;
	        end;
	    end;
		
	    -- Prevents the engine from starting upon entering
	    if not self.allowedIgnition and not self.ignitionKey then
            self.isMotorStarted = false;
            Motorized.stopSounds(self);
	        self.steeringEnabled = false;
            Utils.setEmittingState(self.exhaustParticleSystems, false)
	    end;
	
	    -- Mutes stop sound when engine is off
	    if not self.ignitionKey then
	        self.motorStopSoundVolume = 0;
        else
	        self.motorStopSoundVolume = self.motorStopSoundVolume2;
	    end;
		
	    -- Starts and stops the engine
	    if self.allowedIgnition then
	        if  not self.ignitionKey then
		        self.motorStopSoundVolume = self.motorStopSoundVolume2;
                self:stopMotor();
			    self.steeringEnabled = false;
                self.allowedIgnition = false;	
			    -- Brakes the wheels upon turning off the engine
                for k,wheel in pairs(self.wheels) do
                    setWheelShapeProps(wheel.node, wheel.wheelShape, 0, self.motor.brakeForce, 0);
                end;
                self:onDeactivateAttachements();
	        elseif self.ignitionKey then
                self:startMotor();
                self.steeringEnabled = true;
                self.allowedIgnition = false;
				self.motor.maxRpm[3] = self.motorMaxRpmLimit[3]
       	    end;
	    end;
    -- Prevents the AI from working when engine is off
    elseif not self.ignitionKey and not self.deactivateOnLeave then
		self:stopAICombine();
		self:stopAITractor();
	end;
	
	if self.isMotorStarted and self:getIsActiveForInput() and self.isEntered then
	    if self.motor.speedLevel ~= 0 then
            if InputBinding.isPressed(InputBinding.ACCELERATE) then
		        if self.motor.maxRpm[self.motor.speedLevel] <= (self.motorMaxRpmLimit[3] - 10) then
		            self.motor.maxRpm[self.motor.speedLevel] = self.motor.maxRpm[self.motor.speedLevel] + 10;
			    end;
		    elseif InputBinding.isPressed(InputBinding.DECELERATE) then
		        if self.motor.maxRpm[self.motor.speedLevel] >= 10 then
			        self.motor.maxRpm[self.motor.speedLevel] = self.motor.maxRpm[self.motor.speedLevel] - 10;
			    end;
	    	end;	
		else
            if InputBinding.isPressed(InputBinding.ACCELERATE) then
		        if self.motor.maxRpm[3] <= (self.motorMaxRpmLimit[3] - 10) then
		            self.motor.maxRpm[3] = self.motor.maxRpm[3] + 10;
			    end;
		    elseif InputBinding.isPressed(InputBinding.DECELERATE) then
		        if self.motor.maxRpm[3] >= 10 then
			        self.motor.maxRpm[3] = self.motor.maxRpm[3] - 10;
			    end;
	    	end;
	    end;
	end;
	if self.motor.maxRpm[3] == 0 and self.isMotorStarted then
		self.ignitionKey = not self.ignitionKey;
		self.allowedIgnition = true;
	end;
end;

function EngineUtility:onLeave()
    --Leaves the engine on when AI is driving
	if not self.deactivateOnLeave then
	    self.allowedIgnition = false;
	    self.ignitionKey = true; 
    else
	    self.allowedIgnition = false;
	    self.ignitionKey = false;
	end;
end;

function EngineUtility:draw()
    -- Draws ignition mode and ignition text
    if not self.isMotorStarted and not self.automaticStart then	
        g_currentMission:addHelpButtonText(g_i18n:getText("Start"), InputBinding.IGNITION);
	end;
	if self.isMotorStarted then	
        if self.motor.speedLevel ~= 0 then
			g_currentMission:addExtraPrintText(string.format("Taste %s/%s: %d RPM", InputBinding.getButtonKeyName(InputBinding.ACCELERATE), InputBinding.getButtonKeyName(InputBinding.DECELERATE), self.motor.maxRpm[self.motor.speedLevel]));
            --g_currentMission:addExtraPrintText("Taste NUM +/-:   "..string.format("%d RPM",self.motor.maxRpm[self.motor.speedLevel]).."");
	    else
			g_currentMission:addExtraPrintText(string.format("Taste %s/%s: %d RPM", InputBinding.getButtonKeyName(InputBinding.ACCELERATE), InputBinding.getButtonKeyName(InputBinding.DECELERATE), self.motor.maxRpm[3]));
            --g_currentMission:addExtraPrintText("Taste NUM +/-:   "..string.format("%d RPM",self.motor.maxRpm[3]).."");
	    end;
	end;
end;

--[[function EngineUtility:stopMotor()
	
end;]]