-- @author: kippari2 (klsmods)
-- @date  14.1.2022
--
-- Copyright (C) 


Sampo10 = {};

function Sampo10.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function Sampo10:load(xmlFile)
	--self.openPipe = SpecializationUtil.callSpecializationsFunction("openPipe");
    --self.closePipe = SpecializationUtil.callSpecializationsFunction("closePipe");
	--self.isReelStarted = Sampo10Cutter.isReelStarted
	--self.onReelStart = Cutter.onStartReel;

	local caIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#index"));
	if caIndex ~= nil then
		self.concaveAdjustment = {};
		self.concaveAdjustment.index = caIndex;
		local rx, rx2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#minMaxRotX"));
		self.concaveAdjustment.minRotX = Utils.degToRad(Utils.getNoNil(rx, 0));
		self.concaveAdjustment.maxRotX = Utils.degToRad(Utils.getNoNil(rx2, 0));
	end;
	local ruIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.reelUpDownLever#index1"));
	if ruIndex ~= nil then
		self.reelUpLever = {};
		self.reelUpLever.index = ruIndex;
		local rz, rz2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.reelUpDownLever#minMaxRotZ1"));
		self.reelUpLever.minRotZ = Utils.degToRad(Utils.getNoNil(rz, 0));
		self.reelUpLever.maxRotZ = Utils.degToRad(Utils.getNoNil(rz2, 0));
	end;
	local rdIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.reelUpDownLever#index2"));
	if rdIndex ~= nil then
		self.reelDownLever = {};
		self.reelDownLever.index = rdIndex;
		local rz, rz2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.reelUpDownLever#minMaxRotZ2"));
		self.reelDownLever.minRotZ = Utils.degToRad(Utils.getNoNil(rz, 0));
		self.reelDownLever.maxRotZ = Utils.degToRad(Utils.getNoNil(rz2, 0));
	end;
	local tlIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.thresherLever#index"));
	--print(getXMLString(xmlFile, "vehicle.animatedParts.thresher#leverIndex"));
	if tlIndex ~= nil then
		self.thresherLever = {};
		self.thresherLever.minRot = {};
		self.thresherLever.maxRot = {};
		self.thresherLever.index = tlIndex;
		self.thresherLever.rotationSpeed = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.thresherLever#rotationSpeed"), 2) * 1000;
		local rx, rx2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.thresherLever#minMaxRotX"));
		self.thresherLever.minRot[1] = Utils.degToRad(Utils.getNoNil(rx, 0));
		self.thresherLever.minRot[2] = 0;
		self.thresherLever.minRot[3] = 0;
		self.thresherLever.maxRot[1] = Utils.degToRad(Utils.getNoNil(rx2, 0));
		self.thresherLever.maxRot[2] = 0;
		self.thresherLever.maxRot[3] = 0;
	end;
	local rslIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.reelStopLever#index"));
	if rslIndex ~= nil then
		self.reelStopLever = {};
		self.reelStopLever.minRot = {};
		self.reelStopLever.maxRot = {};
		self.reelStopLever.index = rslIndex;
		self.reelStopLever.rotationSpeed = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.reelStopLever#rotationSpeed"), 2) * 1000;
		local rx, rx2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.reelStopLever#minMaxRotX"));
		self.reelStopLever.minRot[1] = Utils.degToRad(Utils.getNoNil(rx, 0));
		self.reelStopLever.minRot[2] = 0;
		self.reelStopLever.minRot[3] = 0;
		self.reelStopLever.maxRot[1] = Utils.degToRad(Utils.getNoNil(rx2, 0));
		self.reelStopLever.maxRot[2] = 0;
		self.reelStopLever.maxRot[3] = 0;
	end;
	local shieveAnimRootNode = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.animatedParts.shieve#rootNode"));
    self.shieveAnimCharSet = 0;
    if shieveAnimRootNode ~= nil and shieveAnimRootNode ~= 0 then
        self.shieveAnimCharSet = getAnimCharacterSet(shieveAnimRootNode);
		local clip = getAnimClipIndex(self.shieveAnimCharSet, getXMLString(xmlFile, "vehicle.animatedParts.shieve#animationClip"));
		assignAnimTrackClip(self.shieveAnimCharSet, 0, clip);
		setAnimTrackLoopState(self.shieveAnimCharSet, 0, true);
		local shieveAnimSpeedScale = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.shieve#speedScale"), 1);
		setAnimTrackSpeedScale(self.shieveAnimCharSet, 0, shieveAnimSpeedScale);
    end;
	
	self.pipeIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.pipe#index"));
	self.pipeDummyIndex = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.pipeDummy#index"));
	self.grainTankCapacity = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.grainTankCapacity"), 200)

	concaveMM = 7.0;
	concaveMax = 25.0;
	concaveMin = 0.0;
	displayHelp = false;
	displayTValues = false;

	self.hudInfoBaseOverlay = Overlay:new("hudInfoBaseOverlay", "dataS/missions/hud_help_base.png", 0.02, 0.02, 0.345, 0.20)
	tImage = Utils.getFilename("ThreshingValues.png", self.baseDirectory);
	self.threshingValuesOverlay = Overlay:new("threshingValuesOverlay", tImage, 0.512, 0.2, 0.48, 0.48)
end;

function Sampo10:keyEvent(unicode, sym, modifier, isDown)
	if InputBinding.isPressed(InputBinding.HELP) then
		displayHelp = not displayHelp;
	end;
	if InputBinding.isPressed(InputBinding.DISPLAYTVALUES) then
		displayTValues = not displayTValues;
	end;
	--[[if InputBinding.isPressed(InputBinding.THRESHERON) and self.reelStarted then
		self.isThreshing = true;
	end; i experimented with separate thresher and cutter activation]]
end;

function Sampo10:update(dt)
	if self.concaveAdjustment ~= nil then
		local changingRotation = {};
		changingRotation[1], changingRotation[2], changingRotation[3] = getRotation(self.concaveAdjustment.index);
		if InputBinding.isPressed(InputBinding.CONCAVEDOWN) and changingRotation[1] < self.concaveAdjustment.maxRotX then
			changingRotation[1] = changingRotation[1] + 0.002;
			if concaveMM < concaveMax then
				concaveMM = concaveMM + 0.06;
			end;
		end;
		if InputBinding.isPressed(InputBinding.CONCAVEUP) and changingRotation[1] > self.concaveAdjustment.minRotX then
			changingRotation[1] = changingRotation[1] - 0.002;
			if concaveMM > concaveMin then
				concaveMM = concaveMM - 0.06;
			end;
		end;
		if concaveMM < 0 then
			concaveMM = 0.0;
		end;
		if concaveMM > 25.0 then
			concaveMM = 25;
		end;
		setRotation(self.concaveAdjustment.index, unpack(changingRotation));
	end;

	if self.reelUpLever ~= nil and self.reelDownLever ~= nil then
		local changingRotation1 = {};
		changingRotation1[1], changingRotation1[2], changingRotation1[3] = getRotation(self.reelUpLever.index);
		local changingRotation2 = {};
		changingRotation2[1], changingRotation2[2], changingRotation2[3] = getRotation(self.reelDownLever.index);
		if InputBinding.isPressed(InputBinding.REELUP) and changingRotation1[3] < self.reelUpLever.maxRotZ then
			changingRotation1[3] = changingRotation1[3] + 0.01;
		elseif changingRotation1[3] > self.reelUpLever.minRotZ then
			changingRotation1[3] = changingRotation1[3] - 0.01;
		end;
		if InputBinding.isPressed(InputBinding.REELDOWN) and changingRotation2[3] < self.reelDownLever.maxRotZ then
			changingRotation2[3] = changingRotation2[3] + 0.01;
		elseif changingRotation2[3] > self.reelDownLever.minRotZ then
			changingRotation2[3] = changingRotation2[3] - 0.01;
		end;
		setRotation(self.reelUpLever.index, unpack(changingRotation1));
		setRotation(self.reelDownLever.index, unpack(changingRotation2));
	end;
	
	if self.isThreshing then
		tLeverActive = true;
		rslLeverActive = true;
		enableAnimTrack(self.shieveAnimCharSet, 0);
	else
		tLeverActive = false;
		rslLeverActive = false;
		disableAnimTrack(self.shieveAnimCharSet, 0);
	end;
	
	if self.thresherLever ~= nil then
		local currentRotation = {};
		currentRotation[1], currentRotation[2], currentRotation[3] = getRotation(self.thresherLever.index);
		local newRot = Utils.getMovedLimitedValues(currentRotation, self.thresherLever.maxRot, self.thresherLever.minRot, 3, self.thresherLever.rotationSpeed, dt, not tLeverActive);
		setRotation(self.thresherLever.index, unpack(newRot));
	end;
	
	if self.reelStopLever ~= nil then
		local currentRotation = {};
		currentRotation[1], currentRotation[2], currentRotation[3] = getRotation(self.reelStopLever.index);
		local newRot = Utils.getMovedLimitedValues(currentRotation, self.reelStopLever.maxRot, self.reelStopLever.minRot, 3, self.reelStopLever.rotationSpeed, dt, not rslLeverActive);
		setRotation(self.reelStopLever.index, unpack(newRot));
	end;
	
	if self.pipeDummyIndex ~= nil then
		local currentRotation = {};
		currentRotation[1], currentRotation[2], currentRotation[3] = getRotation(self.pipeIndex);
		currentRotation[1] = 0;
		setRotation(self.pipeDummyIndex, unpack(currentRotation));
	end;
end;

function Sampo10:draw()
	if self.isEntered then
		if displayHelp then
			g_currentMission:addHelpButtonText("Help off", InputBinding.HELP);
			self.hudInfoBaseOverlay:render();
			if displayTValues then
				renderText(0.03, 0.06, 0.025, "Threshing values on: " ..  InputBinding.getButtonKeyName(InputBinding.DISPLAYTVALUES));
			else
				renderText(0.03, 0.06, 0.025, "Threshing values off: " ..  InputBinding.getButtonKeyName(InputBinding.DISPLAYTVALUES));
			end;
			renderText(0.03, 0.10, 0.025, "Reel forward & back: " .. InputBinding.getButtonKeyName(InputBinding.REELFORWARD) .. ", " .. InputBinding.getButtonKeyName(InputBinding.REELFORWARD));
			renderText(0.03, 0.08, 0.025, "Reel up & down: " .. InputBinding.getButtonKeyName(InputBinding.REELUP) .. ", " .. InputBinding.getButtonKeyName(InputBinding.REELDOWN));
			renderText(0.03, 0.04, 0.025, "Concave adjustment up & down " .. string.format("%.1f mm", concaveMM) .. InputBinding.getButtonKeyName(InputBinding.CONCAVEAUP) .. ", " .. InputBinding.getButtonKeyName(InputBinding.CONCAVEADOWN));
		else
			g_currentMission:addHelpButtonText("Help on", InputBinding.HELP);
		end;
		
		if displayTValues then
			self.threshingValuesOverlay:render();
		end;
	end;
end;
--g_i18n:getText("Help")
function Sampo10:onEnter()
end;

function Sampo10:onLeave()
end;

function Sampo10:delete()
end;

function Sampo10:mouseEvent(posX, posY, isDown, isUp, button)
end;