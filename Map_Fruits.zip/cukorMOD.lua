print("register fruit type: cukorrepa");

local cukorhudFile = Utils.getFilename("mods/Map_Fruits/cukorHUD.png", getUserProfileAppPath());
FruitUtil.registerFruitType("sugarbeet", true, true, true, 4, 0.4, 1.3, 0.01, 0.5, cukorhudFile);

local origLoadStatsFromXML = QuickPlayMenu.loadStatsFromXML;
local origSowingMachineLoad = SowingMachine.load;

SowingMachine.load = function (self, xmlFile)
	if origSowingMachineLoad ~= nil then
		origSowingMachineLoad(self, xmlFile);
	end;

	self.seeds = {};
	local i = 1;
    for k, fruitType in pairs(FruitUtil.fruitTypes) do
        if fruitType.allowsSeeding then
            self.seeds[i] = fruitType.index;
			i = i + 1;
        end;
    end;
end;

QuickPlayMenu.loadStatsFromXML = function(self, baseXMLName, savegame)
    origLoadStatsFromXML(self, baseXMLName, savegame);
    for i = 1, FruitUtil.NUM_FRUITTYPES do
        if savegame.stats.farmSiloFruitAmount[i] == nil then
            savegame.stats.farmSiloFruitAmount[i] = 5000;
		end;
        if savegame.stats.fruitPrices[i] == nil then
            savegame.stats.fruitPrices[i] = FruitUtil.fruitIndexToDesc[i].pricePerLiter;
        end;
        if savegame.stats.yesterdaysFruitPrices[i] == nil then
            savegame.stats.yesterdaysFruitPrices[i] = FruitUtil.fruitIndexToDesc[i].yesterdaysPrice;
        end;
    end;
end;




