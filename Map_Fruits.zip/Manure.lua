local hudFile = Utils.getFilename("mods/Map_Fruits/ManureHud.png", getUserProfileAppPath());
FruitUtil.registerFruitType("manure",false,false,false,0, 0.005 ,0.01,1,1,hudFile);
print("register fruit type: manure"); 

local origLoadStatsFromXML = QuickPlayMenu.loadStatsFromXML;

QuickPlayMenu.loadStatsFromXML = function(self, baseXMLName, savegame)
	origLoadStatsFromXML(self, baseXMLName, savegame);
	for i = 1, FruitUtil.NUM_FRUITTYPES do
		if savegame.stats.farmSiloFruitAmount[i] == nil then
			savegame.stats.farmSiloFruitAmount[i] = 5000;
		end;
		if savegame.stats.fruitPrices[i] == nil then
			savegame.stats.fruitPrices[i] = FruitUtil.fruitIndexToDesc[i].pricePerLiter;
		end;
		if savegame.stats.yesterdaysFruitPrices[i] == nil then
			savegame.stats.yesterdaysFruitPrices[i] = FruitUtil.fruitIndexToDesc[i].yesterdaysPrice;
		end;
	end;
end;