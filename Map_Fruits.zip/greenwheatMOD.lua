--
-- fruitTypeGreenwheat
--
-- @author C.Schoch
-- @date  12.07.2009

print("register fruit type: greenwheat");
local hudFile = Utils.getFilename("mods/Map_Fruits/greenwheatHud.png", getUserProfileAppPath());
--						        (string name,			bool needsSeeding, 	bool allowsSeeding, 	bool hasStraw, 	int minHarvestingGrowthState, 	float pricePerLiter, 	float literPerQm, 		float seedUsagePerQm, 		float seedPricePerLiter, 	string hudFruitOverlayFilename) 	"C:/Dokumente und Einstellungen/Chef/Eigene Dateien/My Games/FarmingSimulator2009/mods/Greenwheat/greenwheatHud.png"
FruitUtil.registerFruitType("greenwheat",	true, 			true,			false, 		4, 			   			0.42, 			1, 				0.01, 				0.5, 				hudFile);	
	
local origLoadStatsFromXML = QuickPlayMenu.loadStatsFromXML;
local origSowingMachineLoad = SowingMachine.load;

SowingMachine.load = function (self, xmlFile)
	if origSowingMachineLoad ~= nil then
		origSowingMachineLoad(self, xmlFile);
	end;
	
	self.seeds = {};
	local i = 1;
    for k, fruitType in pairs(FruitUtil.fruitTypes) do
        if fruitType.allowsSeeding then
            self.seeds[i] = fruitType.index;
			i = i + 1;
        end;
    end;	
end;
 
QuickPlayMenu.loadStatsFromXML = function(self, baseXMLName, savegame)
    origLoadStatsFromXML(self, baseXMLName, savegame);
    for i = 1, FruitUtil.NUM_FRUITTYPES do
        if savegame.stats.farmSiloFruitAmount[i] == nil then
            savegame.stats.farmSiloFruitAmount[i] = 5000;
        end;
        if savegame.stats.fruitPrices[i] == nil then
            savegame.stats.fruitPrices[i] = FruitUtil.fruitIndexToDesc[i].pricePerLiter;
        end;
        if savegame.stats.yesterdaysFruitPrices[i] == nil then
            savegame.stats.yesterdaysFruitPrices[i] = FruitUtil.fruitIndexToDesc[i].yesterdaysPrice;
        end;
    end;
end;
