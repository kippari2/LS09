GIANTS Maya i3d exporter plugins
================================

Installation
------------

Refer to:
http://gdn.giants.ch/documentation.php#exporter_maya_installation
for installation details

Change log
----------

4.1.2 (01.03.2009)
------------------
 - Added object mask export attribute
 - Added detach faces tool
 - Added custom shader support

4.1.1 (29.12.2008)
------------------
 - Maya 2009 support

4.1.0 (17.10.2008)
------------------
 - New i3d format (v1.6)
   - New and faster mesh format
   - Animation id fix
   - Attribute rename
 - User attributes export

4.0.0 (18.07.2008)
------------------
 - Unified versioning (SDK, Editor and Exporter)

1.1.9 (24.05.2008)
------------------
 - Added blinn material support
 - Fixed non-renderable flag for splines

1.1.8 (11.01.2008)
------------------
 - Added export selection only feature
 - Fixed joint export
 - Fixed nurbs export

1.1.7 (30.11.2007)
------------------
 - Extended frezze to pivot (tools tab) feature
 - Added non renderable flag
 - Added breakable joint support

1.1.6 (17.10.2007)
------------------
 - Fixed support for refraction and reflection maps

1.1.5 (16.10.2007)
------------------
 - Maya 2008 support
 - Added support for refraction and reflection maps
 - Changed default skin width

1.1.4 (19.06.2007)
------------------
 - IK export option
 - Nurbs curve export option
 - Added new compound export attribute

1.1.3 (25.05.2007)
------------------
 - Native i3d LOD support
 - Added compound child flag
 - Fixed compound export
 
1.1.2 (13.04.2007)
------------------
 - Added export default cameras option
 - Fixed nurbs curve export
 - Fixed compound export
 - Fixed exporter to avoid exporting of empty TransformGroups of shapes/cameras/lights/dynamics if not used

1.1.1 (09.03.2007)
------------------
- Minor fixes (light intensity renamed to range and particle system shader to material

1.1.0 (07.03.2007)
------------------
- i3d v1.5 compatible

1.0.8 (14.02.2007)
------------------
- Maya 8.5 version
- Camera TransformGroup merged
- Ignore useless TransformGroups like ViewCompass etc

1.0.7 (05.01.2007)
------------------
- Exports bumpDepth attribute of bump/normal textures (bump2d nodes)
- Set diffuse texture to emissive if glow intesity is 1.0




