-- @author: kippari2 (klsmods)
-- @date  14.1.2022
--
-- Copyright (C) 


Sampo10 = {};

function Sampo10.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function Sampo10:load(xmlFile)
	local caIndex = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#index"));
	--print(getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#index"));
	if caIndex ~= nil then
		self.concaveAdjustment = {};
		self.concaveAdjustment.index = caIndex;
		local rx, rx2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#minMaxRotX"));
		self.concaveAdjustment.minRotX = Utils.degToRad(Utils.getNoNil(rx, 0));
		self.concaveAdjustment.maxRotX = Utils.degToRad(Utils.getNoNil(rx2, 0));
	end;
	local sIndex = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.animatedParts.thresher#shieveIndex"));
	if sIndex ~= nil then
		self.shieve = {};
		self.shieve.index = sIndex;
		self.shieve.transMinZ, self.shieve.transMaxZ = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.thresher#shieveTransMinMaxZ"));
	end;
	local tlIndex = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.animatedParts.thresher#leverIndex"));
	--print(getXMLString(xmlFile, "vehicle.animatedParts.thresher#leverIndex"));
	if tlIndex ~= nil then
		self.thresherLever = {};
		self.thresherLever.minRot = {};
		self.thresherLever.maxRot = {};
		self.thresherLever.index = tlIndex;
		self.thresherLever.rotationSpeed = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.animatedParts.thresher#leverRotationSpeed"), 2) * 1000;
		local rx, rx2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.thresher#leverMinMaxRotX"));
		self.thresherLever.minRot[1] = Utils.degToRad(Utils.getNoNil(rx, 0));
		self.thresherLever.minRot[2] = 0;
		self.thresherLever.minRot[3] = 0;
		self.thresherLever.maxRot[1] = Utils.degToRad(Utils.getNoNil(rx2, 0));
		self.thresherLever.maxRot[2] = 0;
		self.thresherLever.maxRot[3] = 0;
	end;
	self.pipeIndex = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.pipe#Index"));
	
	concaveMM = 7.0;
	concaveMax = 25.0;
	concaveMin = 0.0;
	displayHelp = false;
	displayTValues = false;

	self.hudInfoBaseOverlay = Overlay:new("hudInfoBaseOverlay", "dataS/missions/hud_help_base.png", 0.02, 0.02, 0.345, 0.20)
	tImage = Utils.getFilename("ThreshingValues.png", self.baseDirectory);
	self.threshingValuesOverlay = Overlay:new("threshingValuesOverlay", tImage, 0.512, 0.2, 0.48, 0.48)
end;

function Sampo10:keyEvent(unicode, sym, modifier, isDown)
	if InputBinding.HELP ~= nil and InputBinding.isPressed(InputBinding.HELP) then
		displayHelp = not displayHelp;
	end;
	if InputBinding.DISPLAYTVALUES ~= nil and InputBinding.isPressed(InputBinding.DISPLAYTVALUES) then
		displayTValues = not displayTValues;
	end;
	if isDown and sym == Input.KEY_g then
		tLeverActive = not tLeverActive;
	end;
	if isDown and sym == Input.KEY_b then
		pipeOpen = not pipeOpen;
	end;
end;

function Sampo10:update(dt)
	if self.concaveAdjustment ~= nil then
		local changingRotation = {};
		changingRotation[1], changingRotation[2], changingRotation[3] = getRotation(self.concaveAdjustment.index);
		if InputBinding.CONCAVEDOWN ~= nil and InputBinding.isPressed(InputBinding.CONCAVEDOWN) then
			if changingRotation[1] < self.concaveAdjustment.maxRotX then
				changingRotation[1] = changingRotation[1] + 0.002;
			else
				changingRotation[1] = changingRotation[1];
			end;
			if concaveMM < concaveMax then
				concaveMM = concaveMM + 0.06;
			end;
		end;
		if InputBinding.CONCAVEUP ~= nil and InputBinding.isPressed(InputBinding.CONCAVEUP) then
			if changingRotation[1] > self.concaveAdjustment.minRotX then
				changingRotation[1] = changingRotation[1] - 0.002;
			else
				changingRotation[1] = changingRotation[1];
			end;
			if concaveMM > concaveMin then
				concaveMM = concaveMM - 0.06;
			end;
		end;
		if concaveMM < 0 then
			concaveMM = 0.0;
		end;
		if concaveMM > 25.0 then
			concaveMM = 25;
		end;
		setRotation(self.concaveAdjustment.index, unpack(changingRotation));
	end;
	if self.thresherLever ~= nil then
		local currentRotation = {};
		currentRotation[1], currentRotation[2], currentRotation[3] = getRotation(self.thresherLever.index);
		local newRot = Utils.getMovedLimitedValues(currentRotation, self.thresherLever.maxRot, self.thresherLever.minRot, 3, self.thresherLever.rotationSpeed, dt, not tLeverActive);
		setRotation(self.thresherLever.index, unpack(newRot));
	end;
	--if self.isThreshing then
		
	--end;
end;

function Sampo10:draw()
	if self.isEntered then
		if displayHelp then
			g_currentMission:addHelpButtonText("Help off", InputBinding.HELP);
			self.hudInfoBaseOverlay:render();
			if displayTValues then
				renderText(0.03, 0.06, 0.025, "Threshing values on: " ..  InputBinding.getButtonKeyName(InputBinding.DISPLAYTVALUES));
			else
				renderText(0.03, 0.06, 0.025, "Threshing values off: " ..  InputBinding.getButtonKeyName(InputBinding.DISPLAYTVALUES));
			end;
			renderText(0.03, 0.04, 0.025, "Concave adjustment up & down " .. string.format("%.1f mm", concaveMM) .. InputBinding.getButtonKeyName(InputBinding.CONCAVEAUP) .. ", " .. InputBinding.getButtonKeyName(InputBinding.CONCAVEADOWN));
		else
			g_currentMission:addHelpButtonText("Help on", InputBinding.HELP);
		end;
		if displayTValues then
			self.threshingValuesOverlay:render();
		end;
	end;
end;
--g_i18n:getText("Help")
function Sampo10:onEnter()
end;

function Sampo10:onLeave()
end;

function Sampo10:delete()
end;

function Sampo10:mouseEvent(posX, posY, isDown, isUp, button)
end;