GIANTS MAX i3d exporter plugins
================================

Installation
------------

Copy the plugin file I3DExporter2008.dle or I3DExporter2009.dle into this
directory:

%3DSMAX installation path%/plugins/

On a Windows XP EN this would be this path:

C:\Program Files\Autodesk\3ds Max 2009\plugins

for example.

Change log
----------

4.1.2 (01.03.2009)
------------------
 - Minor bugfixes

4.1.1 (21.11.2008)
------------------
 - Fixed camera near and far clip plane values
 - Fixed empty mesh issue in max exporter
 - Correct Inf normals
 
4.1.0 (24.10.2008)
------------------
 - Initial release


