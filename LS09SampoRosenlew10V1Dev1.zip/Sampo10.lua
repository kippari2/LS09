-- @author: kippari2 (klsmods)
-- @date  14.1.2022
--
-- Copyright (C) 


Sampo10 = {};

function Sampo10.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function Sampo10:load(xmlFile)
	local caIndex = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#index"));
	print(getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#index"));
	if caIndex ~= nil then
		self.concaveAdjustment = {};
		self.concaveAdjustment.index = caIndex;
		local rx, rx2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.concaveAdjustment#minMaxRotX"));
		self.concaveAdjustment.minRotX = Utils.degToRad(Utils.getNoNil(rx, 0));
		self.concaveAdjustment.maxRotX = Utils.degToRad(Utils.getNoNil(rx2, 0));
	end;
	local HP2Index = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.animatedParts.hydraulicPistons#index"));
	if HP2Index ~= nil then
		self.hydraulicPistons = {};
		self.hydraulicPistons.index = HP2Index;
		self.hydraulicPistons.rotationRefIndex = Utils.indexToObject(self.rootNode, getXMLString(xmlFile, "vehicle.animatedParts.hydraulicPistons#rotationRefIndex"));
		local sz, sz2 = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.animatedParts.hydraulicPistons#minMaxScaleZ"));
		self.hydraulicPistons.minScaleZ = sz;
		self.hydraulicPistons.maxScaleZ = sz2;
	end;
	self.concaveMM = 7.0;
	self.concaveMax = 25.0;
	self.concaveMin = 0.0;
	displayHelp = false;
	pistonTrans = {};
	pistonRefTrans = {};
	pistonRotation = {};
	--image = Utils.getFilename("trol.png", self.baseDirectory);
	self.hudInfoBaseOverlay = Overlay:new("hudInfoBaseOverlay", "dataS/missions/hud_help_base.png", 0.02, 0.02, 0.345, 0.20)
end;

function Sampo10:keyEvent(unicode, sym, modifier, isDown)
	--if isDown and sym == input.KEY_ then
	if InputBinding.HELP ~= nil and InputBinding.isPressed(InputBinding.HELP) then
		displayHelp = not displayHelp;
	end;
end;

function Sampo10:update(dt)
	local x, y, z = getRotation(self.concaveAdjustment.index);
	local changingRotation = {x, y, z};
	if InputBinding.CONCAVEDOWN ~= nil and InputBinding.isPressed(InputBinding.CONCAVEDOWN) then
		--print(changingRotation[1], " maxrot ", self.concaveAdjustment.maxRotX);
		if changingRotation[1] < self.concaveAdjustment.maxRotX then
			changingRotation[1] = changingRotation[1] + 0.002;
		else
			changingRotation[1] = changingRotation[1];
		end;
		if self.concaveMM < self.concaveMax then
			self.concaveMM = self.concaveMM + 0.06;
		end;
	end;
	if InputBinding.CONCAVEUP ~= nil and InputBinding.isPressed(InputBinding.CONCAVEUP) then
		--print(changingRotation[1], " minrot ", self.concaveAdjustment.maxRotX);
		if changingRotation[1] > self.concaveAdjustment.minRotX then
			changingRotation[1] = changingRotation[1] - 0.002;
		else
			changingRotation[1] = changingRotation[1];
		end;
		if self.concaveMM > self.concaveMin then
			self.concaveMM = self.concaveMM - 0.06;
		end;
	end;
	if self.concaveMM < 0 then
		self.concaveMM = 0.0;
	end;
	if self.concaveMM > 25.0 then
		self.concaveMM = 25;
	end;
	setRotation(self.concaveAdjustment.index, unpack(changingRotation));
	--the problematic part starts here
	--the thing is calculated using 2d vector math on axis (z, y)
	--most of the references for this calculate it on x and y axis but in farming sim z is forward and y is up and x is the sides
	pistonRotation[1], pistonRotation[2], pistonRotation[3] = getRotation(self.hydraulicPistons.index);
	pistonRefTrans[1], pistonRefTrans[2], pistonRefTrans[3] = getWorldTranslation(self.hydraulicPistons.rotationRefIndex);
	pistonTrans[1], pistonTrans[2], pistonTrans[3] = getWorldTranslation(self.hydraulicPistons.index);
	local det = pistonTrans[3] * pistonRefTrans[3] - pistonTrans[2] * pistonRefTrans[2]; --determinant difinition
	local dot = pistonTrans[3] * pistonRefTrans[3] + pistonTrans[2] * pistonRefTrans[2]; --dot product
	pistonRotation[1] = Utils.degToRad(math.atan2(det, dot) + pistonRotation[1]); --calculating the angle in radians
	setRotation(self.hydraulicPistons.index, unpack(pistonRotation));
	print("piston t ", pistonTrans[1], " ", pistonTrans[2], " ", pistonTrans[3]);
	print("ref t ", pistonRefTrans[1], " ", pistonRefTrans[2], " ", pistonRefTrans[3]);
	print("rotation x ", pistonRotation[1]);
	--setScale();
	--local x, y, z = getRotation(self.concaveAdjustment.index);
	--local currentRot = {x, y, z};
	--local newRot = Utils.getMovedLimitedValues(self.changingRotation, self.concaveAdjustment.maxRot, self.concaveAdjustment.minRot, 3, self.concaveAdjustment.rotationSpeed, dt);
end;

function Sampo10:draw()
	if self.isEntered then
		if displayHelp then
			g_currentMission:addHelpButtonText("Help off", InputBinding.HELP);
			self.hudInfoBaseOverlay:render();
			renderText(0.03, 0.04, 0.025, "Concave adjustment up & down " .. string.format("%.1f mm",self.concaveMM) .. InputBinding.getButtonKeyName(InputBinding.CONCAVEAUP) .. ", " .. InputBinding.getButtonKeyName(InputBinding.CONCAVEADOWN));
		else
			g_currentMission:addHelpButtonText("Help on", InputBinding.HELP);
		end;
	end;
end;
--g_i18n:getText("Help")
function Sampo10:onEnter()
end;

function Sampo10:onLeave()
end;

function Sampo10:delete()
end;

function Sampo10:mouseEvent(posX, posY, isDown, isUp, button)
end;